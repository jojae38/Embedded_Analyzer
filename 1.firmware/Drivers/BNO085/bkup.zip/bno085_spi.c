/*
 * bno085_spi.c
 *
 *  Created on: 2026. 2. 4.
 *      Author: jojae
 */

#include "bno085_spi.h"

#ifdef BNO_SPI

#define READ_LEN 4
static const uint8_t txZeros[BNO_RX_BUFFER_LIMIT] = {0};

//인터럽트
bool isInit = false;
bool intOk = false;
bool inReset = false;
bool rxReady = false;

bool intTrigger = false;
uint32_t intTriggerCount = 0;

bool spiTrigger = false;
uint32_t spiTriggerCount = 0;

static volatile uint32_t rxTimestamp_us;

uint8_t rxBuf[BNO_RX_BUFFER_LIMIT];
static volatile uint32_t rxBufLen;
static volatile bool rxDataReady;

uint8_t txBuf[BNO_TX_BUFFER_LIMIT];
static uint32_t txBufLen;

static sh2_Hal_t sh2Hal;

static void enableInt(void) {intOk = true;}
static void disableInt(void){intOk = false;}
void spiActivate(void);
void spiComplete(void);

BNO_SPI_SEQ bno_seq = SPI_INIT;

static void NSS(bool state){HAL_GPIO_WritePin(SPI3_NSS_GPIO_Port, SPI3_NSS_Pin, state? GPIO_PIN_SET : GPIO_PIN_RESET);}
static void bno085DummyOp(void);
bool bno085SpiTransmitReceive(uint8_t* s_pdata, uint8_t s_len, uint8_t* r_pdata, uint32_t r_len);
void spiRdHdr(void);
void spiRdBody(void);
void spiWrite(void);

bool waitForExtiInt(uint32_t term);
bool waitForInt(uint32_t term);

static void bno085DummyOp(void)
{
  uint8_t dummyTx[1];
  uint8_t dummyRx[1];
  memset(dummyTx,0xAA,sizeof(dummyTx));
  HAL_SPI_TransmitReceive(&BNO_SPI_HANDLER, dummyTx, dummyRx, sizeof(dummyTx), 10);
}

bool bno085SpiTransmitReceive(uint8_t* s_pdata, uint8_t s_len, uint8_t* r_pdata, uint32_t r_len)
{
  NSS(false);
  if(HAL_SPI_Transmit(&BNO_SPI_HANDLER, s_pdata, s_len, 500) != HAL_OK)
    goto error;
  if(HAL_SPI_Receive(&BNO_SPI_HANDLER, r_pdata, r_len, 500) != HAL_OK)
    goto error;

  NSS(true);
  return true;

error:
  NSS(true);
  return false;

}

void bnoSpiReset(void)
{
  disableInt();
  RSTN(false);
  NSS(false);
  delay(10);
  //SPI 모드
  PS0_wake(true);
  PS1(true);
  RSTN(true);

  rxBufLen = 0;
  txBufLen = 0;
  rxDataReady = false;
  rxReady = false;

  inReset = true;
  cliPrintf("RESET START\r\n");

  //SPI SCK 동기화
  bno_seq = SPI_DUMMY;
  bno085DummyOp();
  bno_seq = SPI_IDLE;

  delay(10);
  RSTN(true);

  enableInt();
  delay(200);
  cliPrintf("RESET END\r\n");
  isInit = true;
}

void bnoSpiSeq(void)
{
  if(isInit == false)
    return;

  switch (bno_seq) {
    case SPI_IDLE:
      spiActivate();
      break;
    case SPI_RD_HDR_WAIT:
      break;
    case SPI_RD_HDR:
      spiRdHdr();
      break;
    case SPI_RD_BODY_WAIT:
      break;
    case SPI_RD_BODY:
      spiRdBody();
      break;
    case SPI_WRITE_WAIT:
      break;
    case SPI_WRITE:
      spiWrite();
      break;
    default:
      break;
  }
}

//SPI_IDLE
void spiActivate(void)
{
  if(rxReady && (rxBufLen == 0))
  {
    rxReady = false;
    NSS(false);

    if(txBufLen > 0)
    {
      bno_seq = SPI_WRITE_WAIT;
      HAL_SPI_TransmitReceive_IT(&BNO_SPI_HANDLER, txBuf, rxBuf, txBufLen);
        // Deassert Wake
      PS0_wake(true);
    }
    else
    {
      bno_seq = SPI_RD_HDR_WAIT;
      HAL_SPI_TransmitReceive_IT(&BNO_SPI_HANDLER, (uint8_t *)txZeros, rxBuf, READ_LEN);
    }
  }
}

void spiRdHdr(void)
{
  uint16_t rxLen = (rxBuf[0] + (rxBuf[1] << 8)) & ~0x8000;

  if (rxLen > sizeof(rxBuf))
  {
      rxLen = sizeof(rxBuf);
  }

  if (rxLen > READ_LEN) {
      // There is more to read

      // Transition to RD_BODY state
      bno_seq = SPI_RD_BODY_WAIT;

      // Start a read operation for the remaining length.  (We already read the first READ_LEN bytes.)
      HAL_SPI_TransmitReceive_IT(&BNO_SPI_HANDLER, (uint8_t *)txZeros, rxBuf+READ_LEN, rxLen-READ_LEN);
  }
  else
  {
      // No SHTP payload was received, this operation is done
      NSS(true);            // deassert CSN
      rxBufLen = 0;         // no rx data available
      bno_seq = SPI_IDLE;  // back to idle state
      spiActivate();        // activate next operation, if any.
  }
}

void spiRdBody(void)
{
  uint16_t rxLen = (rxBuf[0] + (rxBuf[1] << 8)) & ~0x8000;

  if (rxLen > sizeof(rxBuf))
  {
      rxLen = sizeof(rxBuf);
  }

  // We completed the read or write of a payload
  // deassert CSN.
  NSS(true);

  // Check len of data read and set rxBufLen
  rxBufLen = rxLen;

  // transition back to idle state
  bno_seq = SPI_IDLE;
}

void spiWrite(void)
{
  uint16_t rxLen = (rxBuf[0] + (rxBuf[1] << 8)) & ~0x8000;

  if (rxLen > sizeof(rxBuf))
  {
      rxLen = sizeof(rxBuf);
  }

  // We completed the read or write of a payload
  // deassert CSN.
  NSS(true);

  // Since operation was a write, transaction was for txBufLen bytes.  So received
  // data len is, at a maximum, txBufLen.
  rxBufLen = (txBufLen < rxLen) ? txBufLen : rxLen;

  // Tx buffer is empty now.
  txBufLen = 0;

  // transition back to idle state
  bno_seq = SPI_IDLE;
}


void extiInterrupt(void)
{
  intTriggerCount ++;
  inReset = false;
  rxReady = true;
}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if(intOk && GPIO_Pin == BNO085_INT_Pin)
  {
    extiInterrupt();
  }
}

void spiInterrupt(void)
{
  spiTriggerCount ++;
  switch (bno_seq) {
    case SPI_DUMMY:
      bno_seq = SPI_INIT;
      break;
    case SPI_RD_HDR_WAIT:
      bno_seq = SPI_RD_HDR;
      break;
    case SPI_RD_BODY_WAIT:
      bno_seq = SPI_RD_BODY;
      break;
    case SPI_WRITE_WAIT:
      bno_seq = SPI_WRITE;
      break;
    default:
      break;
  }
}

void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
  if(intOk && hspi == &BNO_SPI_HANDLER)
  {
//    spiComplete();
    spiInterrupt();
  }
}

// SH2 함수 open / close / write / read / getmillis

bool waitForExtiInt(uint32_t term)
{
  uint32_t timer = millis();
  while(millis() - timer < term)
  {
    if(rxReady)
    {
      rxReady = false;
      return true;
    }
    delay(1);
  }

  bnoSpiReset();
  return false;
}

bool waitForInt(uint32_t term)
{
  uint32_t timer = millis();
  while(millis() - timer < term)
  {
    if(HAL_GPIO_ReadPin(BNO085_INT_GPIO_Port, BNO085_INT_Pin) == GPIO_PIN_RESET)
      return true;
    delay(1);
  }

  bnoSpiReset();
  return false;
}

sh2_Hal_t* sh2Spi_init(void)
{
  sh2Hal.open = sh2SpiOpen;
  sh2Hal.close = sh2SpiClose;
  sh2Hal.read = sh2SpiRead;
  sh2Hal.write = sh2SpiWrite;
  sh2Hal.getTimeUs = sh2SpiMicros;
  return &sh2Hal;
}

int sh2SpiOpen(sh2_Hal_t *self)
{
  bnoSpiReset();
  return SH2_OK;
}

void sh2SpiClose(sh2_Hal_t *self)
{
  RSTN(false);
  NSS(true);

  isInit = false;
  disableInt();
}

int sh2SpiRead(sh2_Hal_t *self, uint8_t *pBuffer, unsigned len, uint32_t *t_us)
{
  int ret = SH2_OK;

  // If there is received data available...
  if (rxBufLen > 0)
  {
      // And if the data will fit in this buffer...
      if (len >= rxBufLen)
      {
          // Copy data to the client buffer
          memcpy(pBuffer, rxBuf, rxBufLen);
          ret = rxBufLen;

          // Set timestamp of that data
          *t_us = rxTimestamp_us;

          // Clear rxBuf so we can receive again
          rxBufLen = 0;
      }
      else
      {
          // Discard what was read and return error because buffer was too small.
          ret = SH2_ERR_BAD_PARAM;
          rxBufLen = 0;
      }

      // Now that rxBuf is empty, activate SPI processing to send any
      // potential write that was blocked.
      disableInt();
      spiActivate();
      enableInt();
  }

  return ret;
}

int sh2SpiWrite(sh2_Hal_t *self, uint8_t *pBuffer, unsigned len)
{
  int ret = SH2_OK;
  if((self == 0) || (len>sizeof(txBuf)) || ((len>0) && (pBuffer == 0)))
  {
    return SH2_ERR_BAD_PARAM;
  }

  if(txBufLen != 0)
  {
    return 0;
  }

  // Copy data to tx buffer
  memcpy(txBuf, pBuffer, len);
  txBufLen = len;
  ret = len;

  // disable SH2 interrupts for a moment
  disableInt();

  // Assert Wake
  PS0_wake(false);

  // re-enable SH2 interrupts.
  enableInt();

  return ret;
}

uint32_t sh2SpiMicros(sh2_Hal_t *self)
{
  return micros();
}

#endif
