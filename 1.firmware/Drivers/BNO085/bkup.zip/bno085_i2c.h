/*
 * bno085_i2c.h
 *
 *  Created on: 2026. 2. 4.
 *      Author: jojae
 */

#ifndef BNO085_BNO085_I2C_H_
#define BNO085_BNO085_I2C_H_

#include "bno085_common.h"

#endif /* BNO085_BNO085_I2C_H_ */
