/*
 * bno085_uartrvc.h
 *
 *  Created on: 2026. 2. 4.
 *      Author: jojae
 */

#ifndef BNO085_BNO085_UARTRVC_H_
#define BNO085_BNO085_UARTRVC_H_

#include "bno085_common.h"

#endif /* BNO085_BNO085_UARTRVC_H_ */
